module.exports = {
    apiUrl: "https://api.everlive.com/v1/GWfRtXi1Lwt4jcqK/"
};
