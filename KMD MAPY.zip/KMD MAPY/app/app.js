var applicationModule = require("application");
applicationModule.mainModule = "views/mapa/mapa";
applicationModule.start();

